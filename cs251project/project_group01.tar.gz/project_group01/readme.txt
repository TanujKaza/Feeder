Group 01
Tanuj Kaza -  100%   150050008
I pledge on my honour that I have not taken any unauthorized assistance on this lab or on any previous one

Harsh Bansal  -   100%   150050109
I pledge on the Gita that I have not taken any unauthorized assistance on this lab or on any previous one

Bhavya Bahl  -   100%   150050110
I pledge on my honour that I have not taken any unauthorized assistance on this lab or on any previous one

Citations
The citations mentioned for Lab 10 and Lab 11
1.https://code.djangoproject.com/wiki/Charts
2.https://www.overleaf.com/6891072hkhgvtnmhcfd#/23527915/
3.https://www.overleaf.com/6891497mprtjyzqwzcn#/23529740/
4.https://developer.android.com/training/basics/firstapp/creating-project.html
5.https://www.studytutorial.in/android-httpurlconnection-post-and-get-request-tutorial
6.http://android-developers.blogspot.in/2013/01/verifying-back-end-calls-from-android.html
7.http://androidexample.com/Android_SharedPreferences_Basics/index.php?view=article_discription&aid=126
8.https://developer.android.com/guide/topics/data/data-storage.html#pref
9.https://www.tutorialspoint.com/android/


Bitbucket Link :: https://tanujkaza@bitbucket.org/bhavya01/projectgroup01.git
Commit ID ::  faa00b1

The bitbucket link for Lab10 and Lab11 was https://tanujkaza@bitbucket.org/bhavya01/project_group01.git
We made some major mistakes in the Git repository on the day of the submission due to which we had to create a new repository for the final submission. For looking at the commits we have made throughout the project, kindly clone the above mentioned repository and for the final submission clone the repository whose link has been mentioned with the commit number. Apologies for the inconvenience.





Reflection Essay:
	This project was the first major project for most of us and certainly on which taught us a lot. Having built websites only in plain-old PHP prior to this, a web framework like Django was a lot easier once we understood how it worked and we got the hang of it. Django has a lot of functionality and very little code is required for it, and this is just what we need in this day and age.

	We learnt how to develop user friendly portals, interactive UI and many mnay other features that Django provides.

	Regarding Social Login, we hit a brick wall when we tried to do login for Gmail using their API. We spent a lot of time on this before we eventually gave up on Gmail Login and attempted to do facebook login at which we succeeded. In hindsight, this time could have been used more wisely.

	Coming to Android, even here we spent almost a whole week trying to do the authentication using oauth and not just plain java. Oauth being more secure was the preferred choice, and although we tried and tried, we finally had to resort to Java to do what we had to do. This I believe was the main reason for not being ablke to complete all the features of the Android Student Interface.
	Some learnings from the Android Project:-
	(
		Can’t use same intent definition in two different functions.
		Get-Post along with Django views makes client-server interaction between them.
		== is not commonly used in Java. object1.equals(object2) is preferred.
		Internet requests better be in Background Threads(“implemented using Async task”), prefer not to use any variable whose value is 	expected from the thread in our Main thread.
		Shared Preferences:- Usage(helped by Lohith) ->
		1. SharedPreferences sharedprefs = this.getApplicationContext();
		2. sharedprefs = getSharedPreferences(“Name for reference”,0(or 1,2,..)) // (int string,int mode)
	)

	All in all, a good project.










